# Classici americani al pianoforte — guida

`[sessione 3c88c123, 04/10/2026]` — corso della serie. Arrangiamenti facili a due mani (melodia a
destra, accordi a sinistra) di folk statunitensi di **pubblico dominio**, per Synthesia.

Le **altezze** delle melodie sono prese da fonte di notazione; l'arrangiamento (ritmo e accordi) e'
nostro e semplice. Tutto in DO maggiore.

**Regola d'oro: prima la sinistra, da sola, lenta. Poi la melodia.**

---

## I brani (3)

| # | File | Note |
|---|---|---|
| 1 | `1_When_the_Saints` | When the Saints Go Marching In: trascinante, 5 note |
| 2 | `2_Oh_Susanna` | Stephen Foster, 1848: la piu' allegra |
| 3 | `3_Yankee_Doodle` | il classico marcetto americano |

Ogni brano ha il suo **MP3** di ascolto.

---

## Onesta' sui file

Folk USA di pubblico dominio (Foster e tradizionali); altezze da fonte, ritmo e accordi nostri, mani
separate. Versioni facili per principianti. Un tasto alla volta.
